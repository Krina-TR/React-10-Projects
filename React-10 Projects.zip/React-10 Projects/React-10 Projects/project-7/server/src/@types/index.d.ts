declare interface IExampleData {
  name: string;
  id: string;
}
